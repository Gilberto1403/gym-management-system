from pydantic import BaseModel
from datetime import date
from typing import Optional

# SOLO para ventas completas
class DetalleVentaSimple(BaseModel):
    producto_id_producto: int
    cantidad: int

class VentaCompleta(BaseModel):
    id_venta: int
    fecha: date
    cliente_id_cliente: int
    gym_id_gym: int
    detalles: list[DetalleVentaSimple]

#------ ESQUEMAS PARA GYM ------
class GYMCreate(BaseModel):
    id_gym: int
    direccion: str

class GYMOut(GYMCreate):
    class Config:
        from_attributes = True

#------ ESQUEMAS PARA CLIENTE ------
#Definimos cómo debe ver un Cliente cuando alguien lo quiere "Crear"
class ClienteCreate(BaseModel):
    id_cliente: int
    nombre: str
    telefono: Optional[str] = None #Puede ir vacio
    suscripcion: str 
    fecha_inscripcion: date
    gym_id_gym: int

#Definimos cómo se ve un Cliente cuando la API "responde"
class ClienteOut(ClienteCreate):
    #Hereda todo lo de ClienteCreate
    class Config:
        from_attributes = True #Permite convertir un objeto SQLAlchemy a este modelo Pydantic
        
#------ ESQUEMAS PARA PRODUCTO ------
class ProductoCreate(BaseModel):
    id_producto: int
    nombre: str
    precio_unitario: float
    stock: int

class ProductoOut(ProductoCreate):
    class Config:
        from_attributes = True

#------ ESQUEMAS PARA EMPLEADO ------
class EmpleadoCreate(BaseModel):
    id_empleado: int
    nombre: str
    telefono: Optional[str] = None
    puesto: str
    gym_id_gym: int

class EmpleadoOut(EmpleadoCreate):
    class Config:
        from_attributes = True

#------ ESQUEMAS PARA VENTA ------
class VentaCreate(BaseModel):
    id_venta: int
    fecha: date
    total_venta: float
    gym_id_gym: int

class VentaOut(VentaCreate):
    class Config:
        from_attributes = True

#------ ESQUEMAS PARA DETALLE_VENTA ------
class DetalleVentaCreate(BaseModel):
    id_detalle: int
    precio_unitario: float
    producto_id_producto: int
    cantidad: int
    subtotal: float
    venta_id_venta: int
    
class DetalleVentaOut(DetalleVentaCreate):
    class Config:
        from_attributes = True