from sqlalchemy import Column, Integer, String, Date, ForeignKey
from sqlalchemy.orm import relationship
from database import Base


class Gym(Base):
    __tablename__ = "gym"

    id_gym = Column(Integer, primary_key=True)
    direccion = Column(String(400), nullable=False)

    clientes = relationship("Cliente", back_populates="gym")
    empleados = relationship("Empleados", back_populates="gym")
    ventas = relationship("Venta", back_populates="gym")


class Cliente(Base):
    __tablename__ = "Clientes"

    id_cliente = Column(Integer, primary_key=True)
    nombre = Column(String(200), nullable=False)
    telefono = Column(String(10))
    suscripcion = Column(String(15), nullable=False)
    fecha_inscripcion = Column(Date, nullable=False)

    gym_id_gym = Column(Integer, ForeignKey("gym.id_gym", ondelete="CASCADE"), nullable=False)

    gym = relationship("Gym", back_populates="clientes")
    ventas = relationship("Venta", back_populates="cliente")


class Empleados(Base):
    __tablename__ = "Empleados"

    id_empleado = Column(Integer, primary_key=True)
    nombre = Column(String(200), nullable=False)
    telefono = Column(String(10))
    puesto = Column(String(15), nullable=False)

    gym_id_gym = Column(Integer, ForeignKey("gym.id_gym", ondelete="CASCADE"), nullable=False)

    gym = relationship("Gym", back_populates="empleados")


class Producto(Base):
    __tablename__ = "Producto"

    id_producto = Column(Integer, primary_key=True)
    nombre = Column(String(200), nullable=False)
    precio_unitario = Column(Integer, nullable=False)
    stock = Column(Integer, nullable=False)

    detalles = relationship("Detalle_Venta", back_populates="producto")


class Venta(Base):
    __tablename__ = "Venta"

    id_venta = Column(Integer, primary_key=True)
    fecha = Column(Date, nullable=False)
    total_venta = Column(Integer, nullable=False)

    gym_id_gym = Column(Integer, ForeignKey("gym.id_gym", ondelete="CASCADE"), nullable=False)
    cliente_id_cliente = Column(Integer, ForeignKey("Clientes.id_cliente", ondelete="CASCADE"), nullable=False)

    gym = relationship("Gym", back_populates="ventas")
    cliente = relationship("Cliente", back_populates="ventas")
    detalles = relationship("Detalle_Venta", back_populates="venta")


class Detalle_Venta(Base):
    __tablename__ = "Detalle_venta"

    id_detalle = Column(Integer, primary_key=True)
    precio_unitario = Column(Integer, nullable=False)
    cantidad = Column(Integer, nullable=False)
    subtotal = Column(Integer, nullable=False)

    venta_id_venta = Column(Integer, ForeignKey("Venta.id_venta", ondelete="CASCADE"), nullable=False)
    producto_id_producto = Column(Integer, ForeignKey("Producto.id_producto", ondelete="CASCADE"), nullable=False)

    venta = relationship("Venta", back_populates="detalles")
    producto = relationship("Producto", back_populates="detalles")