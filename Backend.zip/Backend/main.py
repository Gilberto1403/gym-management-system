from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import engine, get_db
import models, esquemas
from fastapi.middleware.cors import CORSMiddleware

models.Base.metadata.create_all(bind=engine) #Lee las clases models.py 
app = FastAPI(title="Gym 300 System API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permitir todas las fuentes (en producción, especificar dominios)
    allow_credentials=True,
    allow_methods=["*"],  # Permitir todos los métodos HTTP
    allow_headers=["*"],  # Permitir todos los encabezados
)

#------ RUTAS PARA GYM ------
@app.post("/gym/", response_model=esquemas.GYMOut)
def crear_gym(gym: esquemas.GYMCreate, db: Session = Depends(get_db)):
    nuevo_gym = models.Gym(**gym.dict())
    db.add(nuevo_gym)
    try:
        db.commit()
        db.refresh(nuevo_gym)
        return nuevo_gym
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/gym/", response_model=list[esquemas.GYMOut])
def obtener_gym(db: Session = Depends(get_db)):
    gyms = db.query(models.Gym).all()
    return gyms

#------ RUTAS PARA EMPLEADO ------
@app.post("/empleados/", response_model=esquemas.EmpleadoOut)
def crear_empleado(empleado: esquemas.EmpleadoCreate, db: Session = Depends(get_db)):
    nuevo_empleado = models.Empleados(**empleado.dict())
    db.add(nuevo_empleado)
    try:
        db.commit()
        db.refresh(nuevo_empleado)
        return nuevo_empleado
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    
@app.get("/empleados/", response_model=list[esquemas.EmpleadoOut])
def obtener_empleados(db: Session = Depends(get_db)):
    empleados = db.query(models.Empleados).all()
    return empleados

#------ RUTAS PARA CLIENTE ------
#ENDPOINT: Registrar un cliente
#Recibe un 'schemes.ClienteCreate' (los datos del formulario)
@app.post("/clientes/", response_model=esquemas.ClienteOut)
def crear_cliente(cliente: esquemas.ClienteCreate, db: Session = Depends(get_db)):
    #1. Creamos un objeto del Modelo con los datos que llegaron
    nuevo_cliente = models.Cliente(**cliente.dict())

    #2. Lo agregamos a la sesión de la base de datos
    db.add(nuevo_cliente)

    #3. Guardamos los cambios(COMMIT)
    try:
        db.commit()
        db.refresh(nuevo_cliente) #Recargamos para obtener el ID y datos finales
        return nuevo_cliente
    except Exception as e:
        db.rollback() #Si hay error, revertimos los cambios
        raise HTTPException(status_code=400, detail=str(e))
    
#ENDPOINT: Obtener todos los clientes
@app.get("/clientes/", response_model=list[esquemas.ClienteOut])
def obtener_clientes(db: Session = Depends(get_db)):
    clientes = db.query(models.Cliente).all()
    return clientes #Equivale a un SELECT * FROM clientes

#------ RUTAS PARA VENTA ------
@app.post("/ventas/", response_model=esquemas.VentaOut)
def crear_venta(venta: esquemas.VentaCreate, db: Session = Depends(get_db)):
    nueva_venta = models.Venta(**venta.dict())
    db.add(nueva_venta)
    try:
        db.commit()
        db.refresh(nueva_venta)
        return nueva_venta
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    
@app.get("/ventas/", response_model=list[esquemas.VentaOut])
def obtener_ventas(db: Session = Depends(get_db)):
    ventas = db.query(models.Venta).all()
    return ventas

#------ RUTAS PARA DETALLE DE VENTA ------
@app.post("/detalle_venta/", response_model=esquemas.DetalleVentaOut)
def crear_detalle_venta(detalle: esquemas.DetalleVentaCreate, db: Session = Depends(get_db)):
    nuevo_detalle = models.Detalle_Venta(**detalle.dict())
    db.add(nuevo_detalle)
    try:
        db.commit()
        db.refresh(nuevo_detalle)
        return nuevo_detalle
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    
@app.get("/detalle_venta/", response_model=list[esquemas.DetalleVentaOut])
def obtener_detalles_venta(db: Session = Depends(get_db)):
    detalles = db.query(models.Detalle_Venta).all()
    return detalles

#------ RUTAS PARA PRODUCTO ------
@app.post("/producto/", response_model=esquemas.ProductoOut)
def crear_producto(producto: esquemas.ProductoCreate, db: Session = Depends(get_db)):
    nuevo_producto = models.Producto(**producto.dict())
    db.add(nuevo_producto)
    try:
        db.commit()
        db.refresh(nuevo_producto)
        return nuevo_producto
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    
@app.get("/producto/", response_model=list[esquemas.ProductoOut])
def obtener_productos(db: Session = Depends(get_db)):
    productos = db.query(models.Producto).all()
    return productos

#Crearenos un nuevo endpoint para recibir el objeto de ventacompleta
@app.post("/ventas_completas/")
def registrar_venta_total(venta: esquemas.VentaCompleta, db: Session = Depends(get_db)):
    #Encabezado de la venta
    nueva_venta = models.Venta( 
        id_venta=venta.id_venta,
        cliente_id_cliente=venta.cliente_id_cliente,
        gym_id_gym=venta.gym_id_gym,
        fecha=venta.fecha,
        total_venta=0 
    )
    db.add(nueva_venta)
    db.flush() # Importante: asigna el ID a nueva_venta antes de usarlo abajo
    try:
        #Registrar cada producto de Detalle_Venta
        for det in venta.detalles:
            nuevo_detalle = models.Detalle_Venta(
                producto_id_producto=det.producto_id_producto,
                cantidad=det.cantidad,
                precio_unitario=0, # El trigger lo actualizará
                subtotal=0,        # El trigger lo actualizará
                venta_id_venta=nueva_venta.id_venta
            )
            db.add(nuevo_detalle)
        
        db.commit() #Guardamos la venta y sus detalles
        return {"message": "Venta registrada exitosamente"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
