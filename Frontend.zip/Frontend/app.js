//funcion para cambiar entre Registrar, consultar, etc.
function navegar(seccion){
    //ocultar todas las secciones
    document.querySelectorAll('.seccion').forEach(div => div.classList.remove('activa'));
    //muestra la seleccion
    document.getElementById('seccion-'+seccion).classList.add('activa');
}

//funcion que detecta el cambio en el Choicebox de Registrar
function actualizarFormulario(){
    const seleccion = document.getElementById('choice-registrar').value;
    const contenedor = document.getElementById('contenedor-formulario');

    switch (seleccion) {
        case 'cliente':
            contenedor.innerHTML = generarFormularioCliente();
            break;
            
        case 'empleado':
            contenedor.innerHTML = generarFormularioEmpleado();
            break;

        case 'producto':
            contenedor.innerHTML = generarFormularioProducto();
            break;

        case 'venta':
            contenedor.innerHTML = generarFormularioVenta();
            // Asegúrate de que esta línea esté así en tu switch:
            contenedor.innerHTML += `<button class="btn btn-outline-success w-100" onclick="agregarAlCarrito()">Añadir</button>`;
            break;

        default:
            contenedor.innerHTML = `<p class="text-muted">Selecciona una categoría para comenzar el registro.</p>`;
    }
}

// Funciones auxiliares para mantener el código organizado
function generarFormularioCliente() {
    return `
        <div class="card p-4 shadow-sm border-primary">
            <h4 class="mb-3"><i class="bi bi-person-plus"></i> Nuevo Cliente</h4>
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label">ID Cliente</label><input type="number" id="reg-id" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Nombre</label><input type="text" id="reg-nombre" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Teléfono</label><input type="text" id="reg-telefono" class="form-control" maxlength="10"></div>
                <div class="col-md-6"><label class="form-label">Suscripción</label>
                    <select id="reg-suscripcion" class="form-select">
                        <option value="mensualidad">Mensualidad</option>
                        <option value="visita">Visita</option>
                    </select>
                </div>
                <div class="col-md-6"><label class="form-label">Fecha</label><input type="date" id="reg-fecha" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">ID Gym</label><input type="number" id="reg-gym" class="form-control"></div>
                <button class="btn btn-primary mt-3" onclick="guardarCliente()">Guardar Cliente</button>
            </div>
        </div>`;
}
function generarFormularioEmpleado() {
    return `
        <div class="card p-4 shadow-sm border-info">
            <h4 class="mb-3"><i class="bi bi-person-badge"></i> Nuevo Empleado</h4>
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label">ID Empleado</label><input type="number" id="reg-id-emp" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Nombre</label><input type="text" id="reg-nombre-emp" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Puesto</label><input type="text" id="reg-puesto-emp" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">ID Gym</label><input type="number" id="reg-gym-emp" class="form-control"></div>
                <button class="btn btn-info text-white mt-3" onclick="guardarEmpleado()">Guardar Empleado</button>
            </div>
        </div>`;
}
function generarFormularioProducto() {
    return `
        <div class="card p-4 shadow-sm border-warning">
            <h4 class="mb-3 text-warning"><i class="bi bi-box-seam"></i> Nuevo Producto</h4>
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label">ID Producto</label><input type="number" id="prod-id" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Nombre del Producto</label><input type="text" id="prod-nombre" class="form-control" placeholder="Ej: Proteína Whey"></div>
                <div class="col-md-6"><label class="form-label">Precio</label><input type="number" step="0.01" id="prod-precio" class="form-control" placeholder="0.00"></div>
                <div class="col-md-6"><label class="form-label">Stock Inicial</label><input type="number" id="prod-stock" class="form-control" placeholder="Cantidad"></div>
                <button class="btn btn-warning mt-3 w-100" onclick="guardarProducto()">Guardar Producto</button>
            </div>
        </div>`;
}
function generarFormularioVenta() {
    return `
        <div class="card p-4 shadow-sm border-success">
            <h4 class="mb-3 text-success"><i class="bi bi-cart-check"></i> Registrar Venta</h4>
            <div class="row g-3">
                <div class="col-md-4"><label>ID Venta</label><input type="number" id="vent-id" class="form-control"></div>
                <div class="col-md-4"><label>ID Cliente</label><input type="number" id="vent-cliente" class="form-control"></div>
                <div class="col-md-4"><label>ID Gym</label><input type="number" id="vent-gym" class="form-control"></div>
                <div class="col-md-12"><label>Fecha</label><input type="date" id="vent-fecha" class="form-control"></div>

                <hr>
                <h5>Agregar Productos</h5>
                <div class="col-md-5"><label>ID Producto</label><input type="number" id="det-prod" class="form-control"></div>
                <div class="col-md-4"><label>Cantidad</label><input type="number" id="det-cant" class="form-control"></div>
                <div class="col-md-3 d-flex align-items-end">
                    <button class="btn btn-outline-success w-100" onclick="agregarAlCarrito()">Añadir</button>
                </div>

                <div class="col-12 mt-3">
                    <table class="table table-sm" id="tabla-carrito">
                        <thead><tr><th>Prod</th><th>Cant</th></tr></thead>
                        <tbody></tbody>
                    </table>
                </div>

                <button class="btn btn-success mt-3 w-100" onclick="finalizarVentaCompleta()">Finalizar Venta Total</button>
            </div>
        </div>`;
}

//Funciones para guardar cada tipo de registro (cliente, empleado, producto, venta)
async function guardarCliente() {
    const id = document.getElementById('reg-id').value;
    const nombre = document.getElementById('reg-nombre').value;
    const telefono = document.getElementById('reg-telefono').value;
    const suscripcion = document.getElementById('reg-suscripcion').value;
    const fecha = document.getElementById('reg-fecha').value;
    const gym_id = document.getElementById('reg-gym').value;

    if (!id || !nombre || !suscripcion || !fecha || !gym_id || telefono.length !== 10) {
        alert("Por favor, completa todos los campos correctamente.");
        return;
    }

    const clienteData = {
        id_cliente: parseInt(id),
        nombre: nombre,
        telefono: telefono,
        suscripcion: suscripcion,
        fecha_inscripcion: fecha,
        gym_id_gym: parseInt(gym_id)
    };

    console.log("Enviando Cliente a la API:", clienteData);

    try {
        const respuesta = await fetch('http://127.0.0.1:8000/clientes/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(clienteData)
        });

        if (respuesta.ok) {
            alert("Cliente registrado con éxito");
            // Limpiamos el formulario llamando de nuevo a la función del switch
            actualizarFormulario(); 
        } else {
            const errorDetalle = await respuesta.json();
            alert("Error del servidor: " + JSON.stringify(errorDetalle.detail));
        }
    }catch (error) {
        console.error("Error de conexión:", error);
        alert("Error de conexión. Revisa que el Backend esté encendido.");
    }
}
async function guardarEmpleado() {
    //datos usando los IDs específicos del formulario generado en el switch
    const id = document.getElementById('reg-id-emp').value;
    const nombre = document.getElementById('reg-nombre-emp').value;
    const puesto = document.getElementById('reg-puesto-emp').value;
    const gym_id = document.getElementById('reg-gym-emp').value;
    
    const telefonoInput = document.getElementById('reg-telefono-emp');
    const telefono = telefonoInput ? telefonoInput.value : "0000000000";

    //Validación de datos esenciales
    if (!id || !nombre || !puesto || !gym_id) {
        alert("Por favor, llene todos los campos obligatorios para el registro.");
        return;
    }

    const empleadoData = {
        id_empleado: parseInt(id),
        nombre: nombre,
        telefono: telefono,
        puesto: puesto,
        gym_id_gym: parseInt(gym_id)
    };

    console.log("Enviando Empleado a la API:", empleadoData);

    try {
        const respuesta = await fetch('http://127.0.0.1:8000/empleados/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(empleadoData)
        });

        if (respuesta.ok) {
            alert("Empleado registrado con éxito");
            // Limpiamos el formulario llamando de nuevo a la función del switch
            actualizarFormulario(); 
        } else {
            const errorDetalle = await respuesta.json();
            alert("Error del servidor: " + JSON.stringify(errorDetalle.detail));
        }
    } catch (error) {
        console.error("Error de conexión:", error);
        alert("Error de conexión. Revisa que el Backend esté encendido.");
    }
}
async function guardarProducto() {
    const id = document.getElementById('prod-id').value;
    const nombre = document.getElementById('prod-nombre').value;
    const precio = document.getElementById('prod-precio').value;
    const stock = document.getElementById('prod-stock').value;

    if (!id || !nombre || !precio || !stock) {
        alert("Por favor, completa todos los campos para registrar el producto.");
        return;
    }

    const productoData = {
        id_producto: parseInt(id),
        nombre: nombre,
        precio_unitario: parseFloat(precio),
        stock: parseInt(stock)
    };

    console.log("Enviando Producto a la API:", productoData);

    try {
        const respuesta = await fetch('http://127.0.0.1:8000/producto/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(productoData)
        });

        if (respuesta.ok) {
            alert("Producto registrado con éxito");
            // Limpiamos el formulario llamando de nuevo a la función del switch
            actualizarFormulario(); 
        } else {
            const errorDetalle = await respuesta.json();
            alert("Error del servidor: " + JSON.stringify(errorDetalle.detail));
        }
    } catch (error) {
        console.error("Error de conexión:", error);
        alert("Error de conexión. Revisa que el Backend esté encendido.");
    }
}

let carritoTemporal = []; //variable global para guardar los productos antes de enviarlos
function agregarAlCarrito() {
    const idProd = document.getElementById('det-prod').value;
    const cant = document.getElementById('det-cant').value;

    if (idProd && cant){
        carritoTemporal.push({
            producto_id_producto: parseInt(idProd),
            cantidad: parseInt(cant)
        });

        //Actualizar la tabla visual
        const tabla = document.getElementById('tabla-carrito').getElementsByTagName('tbody')[0];
        const fila = tabla.insertRow();
        fila.innerHTML = `<td>${idProd}</td><td>${cant}</td>`;

        //Limpiar los campos para el siguiente producto
        document.getElementById('det-prod').value = '';
        document.getElementById('det-cant').value = '';
    }
}
async function finalizarVentaCompleta() {
    const btn = document.querySelector('button[onclick="finalizarVentaCompleta()"]');
    btn.disabled = true; // Deshabilitamos para evitar duplicados
    btn.innerText = "Procesando...";
        
    if (carritoTemporal.length === 0) {
        alert("El carrito está vacío.");
        return;
    }

    const ventaData = {
        id_venta: parseInt(document.getElementById('vent-id').value),
        cliente_id_cliente: parseInt(document.getElementById('vent-cliente').value),
        gym_id_gym: parseInt(document.getElementById('vent-gym').value),
        fecha: document.getElementById('vent-fecha').value,
        detalles: carritoTemporal
    };

    try {
        const respuesta = await fetch('http://127.0.0.1:8000/ventas_completas/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(ventaData)
        });

        if (respuesta.ok) {
            alert("Venta registrada con éxito");
            carritoTemporal = []; // Limpiamos el arreglo
            actualizarFormulario();
        } else {
            const errorDetalle = await respuesta.json();
            alert("Error del servidor: " + JSON.stringify(errorDetalle.detail));
        }
    } catch (e) {
        alert("Error al finalizar la venta: " + e.message);
    }

    btn.disabled = false;
    btn.innerText = "Finalizar Venta Total";
}